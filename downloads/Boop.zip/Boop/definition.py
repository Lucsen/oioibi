import random
import time

throws = ("Rock", "Paper", "Scissors", "Lizard", "Spock")


def moveon():
    enemy = throws[random.randint(0,4)]
    player = False
    while player == False:
        player = raw_input("Rock, Paper, Scissors, Lizard, or Spock: ")
        if player == enemy:
            print "Tie!"
            again()
        elif player == "Rock":
            if enemy == "Paper":
                print "Ha HA, you can't do anything while you're covered up!"
                again()
            elif enemy == "Spock":
                print "Bang, vaporized"
                again()
            else:
                print "Dang, you won... "
                again()
        elif player == "Paper":
            if enemy == "Scissors":
                print "Snip, Snip, you lose!"
                again()
            elif enemy == "Lizard":
                print "Yum, paper!"
                again()
            else:
                print "Oh darn, you win."
                again()
        elif player == "Scissors":
            if enemy == "Rock":
                print "Boom you're broken!"
                again()
            elif enemy == "Spock":
                print "You're no match for my vulcan strength puny metal slicers!"
                again()
            else:
                print "How could you possibly beat me?"
                again()
        elif player == "Lizard":
            if enemy == "Rock":
                print "Ha HA, I'LL CRUSH YOU!"
                again()
            elif enemy == "Scissors":
                print "DECAPITATED!!!"
                again()
            else:
                print "What? Really, YOU won!?!?!?"
                again()
        elif player == "Spock":
            if enemy == "Lizard":
                print "The poison will kill you slowly."
                again()
            elif enemy == "Paper":
                print "You have been refuted, Mr Spock!"
                again()
            else:
                print "huh, you won. I guess you're just smarter than I am."
                again()
        else:
            print "I'm sorry, what did you say?"
        player = False









def again():
    print "wanna play again?"
    response = raw_input("Yes or No? ")
    if response == "No":
        sys.exit()
    else: moveon()
